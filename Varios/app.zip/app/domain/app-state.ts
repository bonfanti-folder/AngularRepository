export class AppState {

    steps = [];
    lastError = {};
    fecha = '';
    validDayFlag = true;
    productos = [];

}
