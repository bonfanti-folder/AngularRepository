export class AppException {
    error = 'Error del servidor, por favor intente nuevamente';
}
