export class TipoPago {
    id?: number;
    descripcion: string;

    constructor() {
        this.id = 0;
    }
}
