export class Provincia {
    id?: number;
    nombre: string;

    constructor() {
        this.id = 0;
    }
}
