export class MedioPago {
    id?: number;
    descripcion: string;

    constructor() {
        this.id = 0;
    }
}
