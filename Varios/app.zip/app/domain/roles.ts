export class Roles {
    id: number;
    authority: string;
}
