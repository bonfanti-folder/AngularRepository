import { Component } from '@angular/core';

@Component({
    selector: 'app-auth-home',
    template: `
    <router-outlet></router-outlet>`
})
export class AuthHomeComponent {
}
